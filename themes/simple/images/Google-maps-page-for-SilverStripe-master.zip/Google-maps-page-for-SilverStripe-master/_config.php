<?php

Object::add_extension('ContactPage', 'GoogleMapsDecorator');